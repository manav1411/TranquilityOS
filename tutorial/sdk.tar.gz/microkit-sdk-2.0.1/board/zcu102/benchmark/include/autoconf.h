
#pragma once

#include <kernel/gen_config.h>
#include <sel4/gen_config.h>
